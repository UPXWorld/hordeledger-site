@echo off
rem Downloads the newest prices from hordeledger.com into this addon folder. Then type /reload in game.
cd /d "%~dp0"
curl -fsSL -o Data.new https://hordeledger.com/addon/Data.lua
if errorlevel 1 (
  del Data.new 2>nul
  echo Download failed. Your old prices are unchanged.
) else (
  move /y Data.new Data.lua >nul
  echo Prices updated. Type /reload in game, or just log in.
)
pause
