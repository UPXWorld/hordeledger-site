-- HordeLedger market window (/hl): what hordeledger.com shows, as of the Data.lua snapshot.
-- Lines with an item: hover = tooltip, click = search it on the open auction house, shift-click = link it in chat,
-- right-click = its hordeledger.com page in a box you can copy. Lines with only a site address: click for the box.

local data = HordeLedgerData or {}
local p = HordeLedgerPrint
local DB
local frame, tabButtons, lines, current = nil, {}, {}, 1

local function tabs()
    local t = {}
    for _, x in ipairs(data.tabs or {}) do t[#t + 1] = x end
    local host = (data.site and data.site.host) or "hordeledger.com"
    t[#t + 1] = { name = "About", lines = {
        { "|cff33c3ffHordeLedger|r shows auction house prices from " .. host .. " on your item tooltips.", nil, host .. "/" },
        { "Prices are for the " .. (data.scope or "WoW Forever US PvP Horde") .. " auction house. Other realms and the Alliance house differ." },
        { "This snapshot: " .. (data.scan or "none") .. " US Central" .. (HordeLedgerAgeText and HordeLedgerAgeText() and (" (" .. HordeLedgerAgeText() .. ")") or "") .. "." },
        { "|cffffd100Fresh prices|r: the site updates every hour. Download the addon again, or run \"Update Prices.cmd\" in the addon folder, then /reload.", nil, host .. "/addon/" },
        { "|cffffd100Market price|r is the average unit price of the cheapest 25% of units listed. |cffffd100Sells/day|r is an estimate from hourly snapshots.", nil, host .. "/about/" },
        { "|cffffd100Commands|r: /hl <item> price check; /hl web <item> site address; /hl tooltip tooltip lines on/off." },
        { "This addon only reads and shows prices. It never posts, buys or automates anything." },
    } }
    return t
end

local function searchAH(id, text)
    local name = (id and GetItemInfo(id)) or text
    if not name then return end
    name = name:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    local ok = pcall(function()
        if AuctionFrame and AuctionFrame:IsShown() and BrowseName then
            if AuctionFrameTab1 and PanelTemplates_GetSelectedTab(AuctionFrame) ~= 1 then AuctionFrameTab1:Click() end
            BrowseName:SetText(name); AuctionFrameBrowse_Search()
        elseif AuctionHouseFrame and AuctionHouseFrame:IsShown() then
            AuctionHouseFrame.SearchBar.SearchBox:SetText(name); AuctionHouseFrame.SearchBar:StartSearch()
        else
            error("closed")
        end
    end)
    if not ok then p("Open the Auction House to search for " .. name .. ".") end
end

local function getLine(i)
    if lines[i] then return lines[i] end
    local b = CreateFrame("Button", nil, frame.child)
    b:SetWidth(frame.child:GetWidth())
    b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.text:SetPoint("TOPLEFT", 4, 0); b.text:SetWidth(frame.child:GetWidth() - 8)
    b.text:SetJustifyH("LEFT"); b.text:SetSpacing(1)
    b.hl = b:CreateTexture(nil, "HIGHLIGHT"); b.hl:SetAllPoints(); b.hl:SetColorTexture(1, 1, 1, 0.07)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:SetScript("OnEnter", function(self)
        if self.item then
            GameTooltip:SetOwner(self, "ANCHOR_CURSOR_RIGHT"); GameTooltip:SetItemByID(self.item); GameTooltip:Show()
        end
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:SetScript("OnClick", function(self, button)
        local url = self.url or (self.item and HordeLedgerItemURL(self.item))
        if button == "RightButton" or not self.item then
            if url then HordeLedgerShowAddress(url, self.item and GetItemInfo(self.item) or nil)
            elseif self.item then p("That item has no page on the site yet.") end
        elseif IsShiftKeyDown() then
            local _, link = GetItemInfo(self.item)
            if link then ChatEdit_InsertLink(link) end
        else
            searchAH(self.item)
        end
    end)
    lines[i] = b
    return b
end

local function render()
    if not frame then return end
    local all = frame.tabs
    local tab = all[current] or all[1]
    local y = 0
    for i, r in ipairs(tab.lines) do
        local b = getLine(i)
        b.item, b.url = r[2], r[3]
        b.text:SetText(r[1])
        local h = b.text:GetStringHeight() + 4
        b:SetHeight(h); b:ClearAllPoints(); b:SetPoint("TOPLEFT", 0, -y); b:Show()
        b:EnableMouse(r[2] ~= nil or r[3] ~= nil)
        y = y + h
    end
    for i = #tab.lines + 1, #lines do lines[i]:Hide() end
    frame.child:SetHeight(math.max(y, 10))
    frame.scroll:SetVerticalScroll(0)
    for i, tb in ipairs(tabButtons) do
        if i == current then tb:LockHighlight() else tb:UnlockHighlight() end
    end
    local age = HordeLedgerAgeText and HordeLedgerAgeText()
    local stale = data.scanUnix and (time() - data.scanUnix) >= 24 * 3600
    frame.status:SetText((stale and "|cffff8800" or "") .. "Prices from " .. (data.scan or "?") .. " US Central" .. (age and (", " .. age) or "")
                         .. (stale and ". Get fresh ones at hordeledger.com/addon|r" or "."))
end

local function build()
    frame = CreateFrame("Frame", "HordeLedgerWindow", UIParent, "BasicFrameTemplateWithInset")
    frame:SetSize(600, 460)
    local pos = DB and DB.windowPos
    if pos then frame:SetPoint(pos[1], UIParent, pos[1], pos[2], pos[3]) else frame:SetPoint("CENTER", 0, 40) end
    frame:SetMovable(true); frame:EnableMouse(true); frame:RegisterForDrag("LeftButton"); frame:SetClampedToScreen(true)
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local pt, _, _, x, y = self:GetPoint()
        if DB then DB.windowPos = { pt, x, y } end
    end)
    frame:SetFrameStrata("DIALOG")
    tinsert(UISpecialFrames, "HordeLedgerWindow")
    frame.title = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    frame.title:SetPoint("TOP", 0, -5); frame.title:SetText("HordeLedger  |cff999999" .. (data.scope or "") .. "|r")

    frame.tabs = tabs()
    local n = #frame.tabs
    local x = 10
    local w = math.floor((576 - 4 * (n - 1)) / n)
    for i, t in ipairs(frame.tabs) do
        local tb = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
        tb:SetSize(w, 22); tb:SetPoint("TOPLEFT", x, -28); x = x + w + 4
        tb:SetText(t.name)
        tb:SetScript("OnClick", function() current = i; render() end)
        tabButtons[i] = tb
    end

    local sf = CreateFrame("ScrollFrame", nil, frame, "UIPanelScrollFrameTemplate")
    sf:SetPoint("TOPLEFT", 12, -56); sf:SetPoint("BOTTOMRIGHT", -32, 40)
    local child = CreateFrame("Frame", nil, sf); child:SetSize(552, 10); sf:SetScrollChild(child)
    frame.scroll, frame.child = sf, child

    frame.status = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    frame.status:SetPoint("BOTTOMLEFT", 14, 16)
    local hint = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    hint:SetPoint("BOTTOMLEFT", 14, 5); hint:SetText("Click: search the AH. Shift-click: link. Right-click: site page.")

    local web = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    web:SetSize(140, 24); web:SetPoint("BOTTOMRIGHT", -10, 8); web:SetText("hordeledger.com")
    web:SetScript("OnClick", function() HordeLedgerShowAddress(((data.site and data.site.host) or "hordeledger.com") .. "/", "Home page") end)
end

function HordeLedgerShowWindow(tab)
    DB = HordeLedgerPricesDB
    if not frame then build() end
    if frame:IsShown() and not tab then frame:Hide(); return end
    if tab then current = tab end
    render(); frame:Show()
end
