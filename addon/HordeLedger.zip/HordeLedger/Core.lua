-- HordeLedger: auction house prices from hordeledger.com on your item tooltips.
-- Prices are for the WoW Forever US PvP Horde auction house. They come from Data.lua in this folder, which is a
-- snapshot: addons can't use the network, so download a fresh copy from hordeledger.com/addon (or run
-- "Update Prices.cmd" in this folder with the game closed, or before a /reload) to bring it up to date.
--   /hl                 open the market window (Market, Movers, Realms, About)
--   /hl <item>          price check (name, part of a name, or shift-click an item link)
--   /hl web <item>      the item's page on hordeledger.com in a box you can copy (no item: the home page)
--   /hl tooltip         turn the tooltip lines on or off
-- This addon reads prices and shows them. It never posts, buys, cancels or automates anything.

local ADDON = ...
local data = HordeLedgerData or { items = {} }
local items = data.items or {}
local site = data.site or {}
local HOST = site.host or "hordeledger.com"
local DB

local function p(msg) DEFAULT_CHAT_FRAME:AddMessage("|cff33c3ffHordeLedger:|r " .. msg) end
HordeLedgerPrint = p

local function coin(c)
    if not c then return "?" end
    c = math.floor(c + 0.5)
    local g, s, cc = math.floor(c / 10000), math.floor(c / 100) % 100, c % 100
    if g > 0 then return string.format("%dg %ds %dc", g, s, cc) end
    if s > 0 then return string.format("%ds %dc", s, cc) end
    return cc .. "c"
end

local function ageText()
    if not data.scanUnix then return nil end
    local h = (time() - data.scanUnix) / 3600
    if h < 1 then return "under an hour old" end
    if h < 48 then return string.format("%d hour%s old", h, h < 2 and "" or "s") end
    return string.format("%d days old", h / 24)
end
HordeLedgerAgeText = ageText

-- ---------------------------------------------------------------- lookups
-- row = { name, lowest, market, qty (0 = not listed now), pos (0-100 of 7-day range), low7, high7, change24 (%), soldPerDay,
--         postPrice, postCode, postNote, bestHours, change7 (%), sitePath, trend, trend %/day, this house/other houses, houses }
local byName = {}
for id, r in pairs(items) do if r[1] then byName[string.lower(r[1])] = id end end

local function lookup(text)
    local id = tonumber(string.match(text, "item:(%d+)"))
    if id then return id end
    local q = string.lower(strtrim(text))
    if q == "" then return nil end
    if byName[q] then return byName[q] end
    local best
    for name, i in pairs(byName) do
        if string.find(name, q, 1, true) and (not best or #name < #best[1]) then best = { name, i } end
    end
    return best and best[2]
end

local function sells(r)
    local spd = r[9]
    if not spd then return nil end
    if spd < 0.3 then return "|cffff6060barely sells|r" end
    local col = (spd >= (r[4] or 0) * 0.5 or spd >= 50) and "|cff40ff40" or (spd >= (r[4] or 0) * 0.15 and "|cffffd100" or "|cffff9040")
    return string.format("%ssells ~%s/day|r", col, spd >= 10 and tostring(math.floor(spd + 0.5)) or tostring(spd))
end

local function describe(id)
    local r = items[id]
    if not r then return nil end
    if (r[4] or 0) == 0 then
        local s = "not listed in the latest snapshot" .. (r[3] and (", last market " .. coin(r[3])) or "")
        if r[6] and r[7] then s = s .. string.format(" | 7d range %s-%s", coin(r[6]), coin(r[7])) end
        return s
    end
    local s = string.format("lowest %s, market %s, %d listed", coin(r[2]), coin(r[3]), r[4] or 0)
    local sp = sells(r)
    if sp then s = s .. " | " .. sp end
    if r[5] then s = s .. string.format(" | %d%% of 7d range (%s-%s)", r[5], coin(r[6]), coin(r[7])) end
    if r[8] then s = s .. string.format(" | 24h %+d%%", r[8]) end
    if (r[4] or 0) < 10 then s = s .. " | THIN" end
    return s
end

-- Posting advice: nil when the usual "undercut the lowest" is fine and nothing is worth saying.
local POSTCOL = { dump = "|cffff8040", vendor = "|cffff4040", spike = "|cff40ff40", slow = "|cffffd100", thin = "|cffffd100", falling = "|cffffd100" }
local TOOLTIP_CODES = { dump = true, vendor = true, spike = true, slow = true }
local function postAdvice(id, always)
    local r = items[id]
    if not r or not r[11] or r[11] == "none" then return nil end
    local code, price, note = r[11], r[10], r[12] or ""
    if not always and not TOOLTIP_CODES[code] then return nil end
    local col = POSTCOL[code] or "|cffcccccc"
    if code == "vendor" then return col .. "Don't post:|r " .. note end
    return string.format("%sPost at %s|r: %s", col, coin(price), note)
end

local TRENDCOL = { ["rising fast"] = "|cff40ff40", ["rising slowly"] = "|cff9be89b", ["stable"] = "|cffcccccc",
                   ["falling slowly"] = "|cffffb070", ["falling fast"] = "|cffff6060", ["volatile"] = "|cffffd100", ["choppy"] = "|cffffd100" }
local function trendText(id)
    local r = items[id]
    if not r then return nil end
    local parts = {}
    if r[14] then parts[#parts + 1] = string.format("7d %+d%%", r[14]) end
    if r[16] then
        parts[#parts + 1] = (TRENDCOL[r[16]] or "") .. r[16] .. "|r" .. (r[17] and string.format(" (%+.1f%%/day)", r[17]) or "")
    end
    if #parts > 0 then return table.concat(parts, " | ") end
end

-- This house against the other busy Forever houses, both priced on the weekly snapshot day.
local function elsewhereText(id, notableOnly)
    local r = items[id]
    if not r or not r[18] then return nil end
    local rel = r[18]
    if notableOnly and rel > 0.75 and rel < 1.33 then return nil end
    local what
    if rel < 0.95 then what = string.format("|cff40ff40%d%% cheaper here|r", math.floor((1 - rel) * 100 + 0.5))
    elseif rel >= 3 then what = string.format("|cffffb070%d times the price here|r", math.floor(rel + 0.5))
    elseif rel > 1.05 then what = string.format("|cffffb070%d%% dearer here|r", math.floor((rel - 1) * 100 + 0.5))
    else what = "about the same here" end
    return string.format("Other Forever houses: %s (%d houses, %s)", what, r[19] or 0, site.housesDay or "weekly")
end

local function siteURL(id)
    local r = id and items[id]
    if r and r[15] then return HOST .. r[15] end
end
HordeLedgerItemURL = siteURL

-- ---------------------------------------------------------------- vendor prices
-- Vendor.lua is a Classic list of items vendors sell. Merchants you open are remembered on top of it (the real price
-- you pay), saved on your own PC only.
local vendorList = HordeLedgerVendorList or {}

local function vendorInfo(id)
    local seen = DB and DB.vendor and DB.vendor[id]
    if seen then
        local best, n
        for npc, v in pairs(seen) do
            n = (n or 0) + 1
            if not best or v.p < best.p then best = { p = v.p, q = v.q, npc = npc, z = v.z, lim = v.lim } end
        end
        if best then
            return best.p, best.q or 1, best.npc .. (best.z and best.z ~= "" and (", " .. best.z) or "")
                           .. (best.lim and ", limited stock" or "") .. (n > 1 and string.format(" +%d more", n - 1) or "")
        end
    end
    local v = vendorList[id]
    if v then return v[1] / (v[2] or 1), v[2] or 1, "Classic vendor list" end
end

local function vendorLine(id)
    local unit, per, where = vendorInfo(id)
    if not unit then return nil end
    local price = (unit >= 1 or per <= 1) and coin(unit) or (coin(unit * per) .. " per " .. per)
    if unit >= 1 and per > 1 then price = price .. " (" .. coin(unit * per) .. " for " .. per .. ")" end
    local s = "|cffffd100Sold by vendor:|r " .. price .. " |cff999999(" .. where .. ")|r"
    local r = items[id]
    if r and r[2] and r[2] > 0 and (r[4] or 0) > 0 then
        if r[2] > unit * 1.05 then s = s .. "  |cff40ff40buy at the vendor|r"
        elseif r[2] < unit * 0.95 then s = s .. "  |cff40ff40AH is cheaper|r" end
    end
    return s
end

local function learnMerchant()
    if not DB then return end
    local npc = UnitName("npc")
    local n = GetMerchantNumItems and GetMerchantNumItems() or 0
    if not npc or n == 0 then return end
    DB.vendor = DB.vendor or {}
    local zone = GetRealZoneText and GetRealZoneText() or ""
    for i = 1, n do
        local price, qty, avail, ext
        if C_MerchantFrame and C_MerchantFrame.GetItemInfo then
            local info = C_MerchantFrame.GetItemInfo(i)
            if info then price, qty, avail, ext = info.price, info.stackCount, info.numAvailable, info.hasExtendedCost end
        elseif GetMerchantItemInfo then
            local _
            _, _, price, qty, avail, _, _, ext = GetMerchantItemInfo(i)
        end
        local link = GetMerchantItemLink and GetMerchantItemLink(i)
        local id = link and tonumber(string.match(link, "item:(%d+)"))
        if id and price and price > 0 and not ext then
            DB.vendor[id] = DB.vendor[id] or {}
            DB.vendor[id][npc] = { p = price / math.max(1, qty or 1), q = math.max(1, qty or 1), z = zone, lim = (avail or -1) >= 0 or nil, t = time() }
        end
    end
end

-- ---------------------------------------------------------------- tooltips
local function addTooltip(tt, id)
    if not id or (DB and DB.tooltip == false) then return end
    if HordeLedgerMarket then return end      -- the owner's private HordeLedgerAsk addon already adds these lines
    local d, vl = describe(id), vendorLine(id)
    if d then
        tt:AddLine("|cff33c3ffHordeLedger|r " .. d, 0.85, 0.85, 0.85, true)
        local pa = postAdvice(id)
        if pa then tt:AddLine(pa, 0.85, 0.85, 0.85, true) end
        local r = items[id]
        if r[16] == "rising fast" or r[16] == "falling fast" then tt:AddLine("Trend: " .. trendText(id), 0.85, 0.85, 0.85, true) end
        local ew = elsewhereText(id, true)
        if ew then tt:AddLine(ew, 0.85, 0.85, 0.85, true) end
    end
    if vl then tt:AddLine(vl, 0.85, 0.85, 0.85, true) end
    if d or vl then tt:Show() end
end
if TooltipDataProcessor and Enum and Enum.TooltipDataType then
    TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tt, info)
        if tt == GameTooltip or tt == ItemRefTooltip then addTooltip(tt, info and info.id) end
    end)
else
    local function hook(tt)
        tt:HookScript("OnTooltipSetItem", function(self)
            local _, link = self:GetItem()
            addTooltip(self, link and tonumber(string.match(link, "item:(%d+)")))
        end)
    end
    hook(GameTooltip); hook(ItemRefTooltip)
end

-- ---------------------------------------------------------------- address box
-- Addons can't open a browser: show the address in a box, selected, ready for Ctrl+C.
local urlFrame
local function showURL(url, label)
    if not url then return end
    if not urlFrame then
        urlFrame = CreateFrame("Frame", "HordeLedgerURLBox", UIParent, "BasicFrameTemplateWithInset")
        urlFrame:SetSize(430, 96); urlFrame:SetPoint("CENTER", 0, 160); urlFrame:SetFrameStrata("FULLSCREEN_DIALOG")
        urlFrame:SetMovable(true); urlFrame:EnableMouse(true); urlFrame:RegisterForDrag("LeftButton")
        urlFrame:SetScript("OnDragStart", urlFrame.StartMoving); urlFrame:SetScript("OnDragStop", urlFrame.StopMovingOrSizing)
        urlFrame.title = urlFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        urlFrame.title:SetPoint("TOP", 0, -5); urlFrame.title:SetText("HordeLedger.com")
        urlFrame.label = urlFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        urlFrame.label:SetPoint("TOPLEFT", 14, -32); urlFrame.label:SetWidth(400); urlFrame.label:SetJustifyH("LEFT")
        local eb = CreateFrame("EditBox", nil, urlFrame, "InputBoxTemplate")
        eb:SetSize(396, 20); eb:SetPoint("BOTTOMLEFT", 18, 16); eb:SetAutoFocus(true)
        eb:SetScript("OnEscapePressed", function() urlFrame:Hide() end)
        eb:SetScript("OnEnterPressed", function() urlFrame:Hide() end)
        eb:SetScript("OnTextChanged", function(self)
            if self:GetText() ~= self.url then self:SetText(self.url or ""); self:HighlightText() end
        end)
        urlFrame.eb = eb
        tinsert(UISpecialFrames, "HordeLedgerURLBox")
    end
    urlFrame.label:SetText((label or "Page") .. "  |cff999999Ctrl+C to copy, Esc to close|r")
    urlFrame.eb.url = "https://" .. url
    urlFrame.eb:SetText(urlFrame.eb.url); urlFrame:Show(); urlFrame.eb:SetFocus(); urlFrame.eb:HighlightText()
end
HordeLedgerShowAddress = showURL

-- ---------------------------------------------------------------- price check
local function priceCheck(msg)
    local id = lookup(msg)
    local d = id and describe(id)
    if d then
        local r = items[id]
        p((r[1] or msg) .. ": " .. d)
        local pa = postAdvice(id, true)
        if pa then p("  " .. pa) end
        if r[13] and r[13] ~= "" then p("  |cff999999" .. r[13] .. " (US Central)|r") end
        local tr = trendText(id)
        if tr then p("  Trend: " .. tr) end
        local ew = elsewhereText(id)
        if ew then p("  " .. ew) end
        local vl = vendorLine(id)
        if vl then p("  " .. vl) end
        local url = siteURL(id)
        if url then p("  |cff999999Charts and history: " .. url .. "  (/hl web " .. (r[1] or msg) .. " to copy)|r") end
    elseif id and vendorLine(id) then
        p(msg .. ": " .. vendorLine(id))
    else
        p("No price for '" .. msg .. "' in this snapshot (" .. (data.scan or "?") .. ").")
    end
end

-- ---------------------------------------------------------------- AH sell slot: one-line posting hint
local hinted = {}
local function sellSlotHint()
    if HordeLedgerMarket or not GetAuctionSellItemInfo then return end
    local ok, name, _, _, _, _, _, _, _, _, itemID = pcall(GetAuctionSellItemInfo)
    if not ok or not name then return end
    local id = itemID or byName[string.lower(name)]
    if not id or hinted[id] then return end
    hinted[id] = true
    local r = items[id]
    if not r or (r[4] or 0) == 0 then return end
    local pa, sp = postAdvice(id, true), sells(r)
    p(name .. ": " .. (pa or ("lowest " .. coin(r[2]))) .. (sp and (" (" .. sp .. ")") or "")
      .. ((r[13] and r[13] ~= "") and (" |cff999999" .. r[13] .. "|r") or ""))
end

-- ---------------------------------------------------------------- startup
local ev = CreateFrame("Frame")
ev:RegisterEvent("ADDON_LOADED"); ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("MERCHANT_SHOW"); ev:RegisterEvent("MERCHANT_UPDATE")
ev:RegisterEvent("NEW_AUCTION_UPDATE"); ev:RegisterEvent("AUCTION_HOUSE_CLOSED")
ev:SetScript("OnEvent", function(_, e, name)
    if e == "ADDON_LOADED" then
        if name ~= ADDON then return end
        HordeLedgerPricesDB = HordeLedgerPricesDB or {}
        DB = HordeLedgerPricesDB
    elseif e == "PLAYER_LOGIN" then
        if not data.scan then p("No price data found. Download the addon again from " .. HOST .. "/addon"); return end
        local age = data.scanUnix and (time() - data.scanUnix) / 3600 or 0
        local msg = "prices from " .. data.scan .. " US Central (" .. (ageText() or "?") .. "), " .. (data.scope or "US PvP Horde") .. ". /hl for the market window."
        if age >= 24 then msg = msg .. " |cffff8800These are stale: get fresh ones at " .. HOST .. "/addon|r" end
        p(msg)
        if UnitFactionGroup and UnitFactionGroup("player") ~= "Horde" then
            p("|cffff8800These are Horde auction house prices; your faction's house will differ.|r")
        end
    elseif e == "MERCHANT_SHOW" or e == "MERCHANT_UPDATE" then
        C_Timer.After(0.3, function() pcall(learnMerchant) end)
    elseif e == "AUCTION_HOUSE_CLOSED" then
        wipe(hinted)
    else
        sellSlotHint()
    end
end)

-- ---------------------------------------------------------------- slash command
SLASH_HORDELEDGER1 = "/hl"
SLASH_HORDELEDGER2 = "/hordeledger"
SlashCmdList.HORDELEDGER = function(msg)
    msg = strtrim(msg or "")
    local low = string.lower(msg)
    if msg == "" then
        if HordeLedgerShowWindow then HordeLedgerShowWindow() end
    elseif low == "help" or low == "?" then
        p("/hl = market window; /hl <item> = price check; /hl web <item> = site address to copy; /hl tooltip = tooltip lines on/off.")
    elseif low == "tooltip" or low == "tooltips" then
        DB.tooltip = (DB.tooltip == false)
        p("Tooltip prices are " .. (DB.tooltip and "on" or "off") .. ".")
    elseif low == "web" then
        showURL(HOST .. "/", "Home page")
    elseif string.sub(low, 1, 4) == "web " then
        local q = strtrim(string.sub(msg, 5))
        local id = lookup(q)
        local url = siteURL(id)
        if url then showURL(url, items[id][1])
        elseif id and items[id] then p((items[id][1] or q) .. " has no page on the site yet (too little price history).")
        else p("No item matches '" .. q .. "'.") end
    else
        priceCheck(msg)
    end
end
